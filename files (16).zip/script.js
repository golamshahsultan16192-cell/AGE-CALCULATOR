'use strict';

/* ---------- Helpers ---------- */
const $ = id => document.getElementById(id);
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const WEEKDAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const ZODIAC = [
  [120,'Aquarius','♒','January 20 – February 18'],
  [219,'Pisces','♓','February 19 – March 20'],
  [321,'Aries','♈','March 21 – April 19'],
  [420,'Taurus','♉','April 20 – May 20'],
  [521,'Gemini','♊','May 21 – June 20'],
  [621,'Cancer','♋','June 21 – July 22'],
  [723,'Leo','♌','July 23 – August 22'],
  [823,'Virgo','♍','August 23 – September 22'],
  [923,'Libra','♎','September 23 – October 22'],
  [1023,'Scorpio','♏','October 23 – November 21'],
  [1122,'Sagittarius','♐','November 22 – December 21'],
  [1222,'Capricorn','♑','December 22 – January 19']
];
const MILESTONES = [1000, 5000, 10000, 20000, 25000, 30000];

const num = n => Math.floor(n).toLocaleString('en-US');
const p2 = n => String(n).padStart(2, '0');
const plural = (n, w) => `${num(n)} ${w}${n === 1 ? '' : 's'}`;
const daysInMonth = (y, m) => new Date(y, m + 1, 0).getDate();      // m is 0-based; m = -1 works
const utc = d => Date.UTC(d.getFullYear(), d.getMonth(), d.getDate());
const dayDiff = (a, b) => Math.round((utc(b) - utc(a)) / 864e5);      // DST-safe
const longDate = d => `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
const toISO = d => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
const todayStart = () => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate()); };

function parseDate(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || '');
  if (!m) return null;
  const y = +m[1], mo = +m[2] - 1, d = +m[3];
  if (y < 1000) return null;
  const dt = new Date(y, mo, d);
  return dt.getFullYear() === y && dt.getMonth() === mo && dt.getDate() === d ? dt : null;
}

/* Calendar difference (years, months, days) — never just subtracts years */
function calDiff(a, b) {
  let y = b.getFullYear() - a.getFullYear();
  let m = b.getMonth() - a.getMonth();
  let d = b.getDate() - a.getDate();
  if (d < 0) { m--; d += daysInMonth(b.getFullYear(), b.getMonth() - 1); }
  if (m < 0) { y--; m += 12; }
  return { y, m, d };
}

function zodiacOf(d) {
  const v = (d.getMonth() + 1) * 100 + d.getDate();
  let z = ZODIAC[ZODIAC.length - 1];
  for (const item of ZODIAC) if (item[0] <= v) z = item;
  return { name: z[1], symbol: z[2], range: z[3] };
}

function nextBirthday(dob, asOf) {
  const make = y => {
    let m = dob.getMonth(), d = dob.getDate();
    if (m === 1 && d === 29 && daysInMonth(y, 1) === 28) d = 28;   // Feb 29 → Feb 28 in non-leap years
    return new Date(y, m, d);
  };
  let next = make(asOf.getFullYear());
  if (next < asOf) next = make(asOf.getFullYear() + 1);
  return { date: next, days: dayDiff(asOf, next), parts: calDiff(asOf, next), today: dayDiff(asOf, next) === 0 };
}

/* ---------- State ---------- */
const state = { dob: null, asOf: null, live: false, name: '', timer: null, summary: '' };

/* ---------- Validation ---------- */
function validate() {
  const today = todayStart();
  const dobStr = $('dob').value, asStr = $('asOf').value;
  if (!dobStr) return { error: 'Please enter a valid date of birth.' };
  const dob = parseDate(dobStr);
  if (!dob) return { error: 'Please enter a valid date of birth.' };
  if (dob > today) return { error: 'Date of birth cannot be in the future.' };
  let asOf = today;
  if (asStr) {
    asOf = parseDate(asStr);
    if (!asOf) return { error: 'Please enter a valid comparison date.' };
    if (asOf > today) return { error: 'The comparison date cannot be in the future.' };
  }
  if (dob > asOf) return { error: 'Date of birth cannot be later than the comparison date.' };
  return { dob, asOf };
}

function showError(el, msg) { el.textContent = msg; el.hidden = !msg; }

/* ---------- Calculation ---------- */
function measure() {
  const { dob, asOf, live } = state;
  const now = new Date();
  const t = live ? now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds() : 0;
  const days = dayDiff(dob, asOf);
  const secs = days * 86400 + t;
  return { c: calDiff(dob, asOf), days, secs, t, h: Math.floor(t / 3600), mi: Math.floor(t % 3600 / 60), s: t % 60 };
}

const card = (value, label) => `<div class="stat"><b>${value}</b><span>${label}</span></div>`;
const row = (k, v) => `<div><dt>${k}</dt><dd>${v}</dd></div>`;

function calculate() {
  const v = validate();
  showError($('err'), v.error || '');
  if (v.error) return;

  stopTimer();
  state.dob = v.dob;
  state.asOf = v.asOf;
  state.live = dayDiff(v.asOf, todayStart()) === 0;
  state.name = $('name').value.trim();
  render();
  $('results').hidden = false;
  $('results').classList.remove('reveal'); void $('results').offsetWidth; $('results').classList.add('reveal');
  $('results').scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
  startTimer();
}

function render() {
  const { dob, asOf, name, live } = state;
  const m = measure();
  const { c } = m;
  const nb = nextBirthday(dob, asOf);
  const z = zodiacOf(dob);
  const totalMonths = c.y * 12 + c.m;
  const ageStr = `${plural(c.y, 'Year')} ${plural(c.m, 'Month')} ${plural(c.d, 'Day')}`;
  const dobStr = longDate(dob);
  const dayName = WEEKDAYS[dob.getDay()];

  $('hello').textContent = name ? `Hello, ${name} 👋` : '';
  countUp($('bigYears'), c.y);
  $('ageText').textContent = ageStr;
  $('asOfNote').textContent = live ? `Calculated for today, ${longDate(asOf)}.` : `Age as of ${longDate(asOf)}.`;

  $('exactCards').innerHTML =
    card(plural(c.y, 'Year'), 'Exact age in years') +
    card(plural(totalMonths, 'Month'), 'Exact age in months') +
    card(plural(m.days, 'Day'), 'Exact age in days');

  const wk = Math.floor(m.days / 7);
  $('facts').innerHTML = [
    `You have lived ${m.days === 0 ? 'less than a day' : 'exactly ' + plural(m.days, 'day')} (${plural(wk, 'week')}).`,
    `You have completed ${plural(c.y, 'year')} of life${c.m || c.d ? `, plus ${plural(c.m, 'month')} and ${plural(c.d, 'day')}` : ''}.`,
    `Roughly ${num(m.days / 3)} of those days were spent asleep (about 8 hours a night) — an estimate.`,
    nb.today ? '🎉 Today is your birthday!' : `Your next birthday falls on a ${WEEKDAYS[nb.date.getDay()]}, in ${plural(nb.days, 'day')}.`,
    nextMilestoneFact()
  ].map(f => `<li>${f}</li>`).join('');

  $('liveNote').textContent = live ? 'Updates every second.' : `Showing your age at the start of ${longDate(asOf)} (choose today's date for a ticking counter).`;
  renderLive(m);

  $('units').innerHTML =
    card(plural(c.y, 'Year'), 'Age in years (exact)') +
    card(plural(totalMonths, 'Month'), 'Age in months (exact)') +
    card(`<span id="uW">${num(wk)}</span> Weeks`, 'Age in weeks (days ÷ 7)') +
    card(`<span id="uD">${num(m.days)}</span> Days`, 'Age in days (exact)') +
    card(`<span id="uH">${num(Math.floor(m.secs / 3600))}</span> Hours`, 'Age in hours (approx.)') +
    card(`<span id="uM">${num(Math.floor(m.secs / 60))}</span> Minutes`, 'Age in minutes (approx.)') +
    card(`<span id="uS">${num(m.secs)}</span> Seconds`, 'Age in seconds (approx.)');

  $('nextBday').innerHTML = nb.today
    ? `<p class="party">🎉 Happy Birthday!</p><p class="muted">Today is your birthday — you turn ${plural(c.y, 'year')} old.</p>`
    : `<p class="nb-date">🎂 ${longDate(nb.date)}</p>
       <p><b>${WEEKDAYS[nb.date.getDay()]}</b></p>
       <span class="nb-days">⏳ ${plural(nb.days, 'Day')} remaining</span>
       <p class="muted">That is ${plural(nb.parts.m, 'month')} and ${plural(nb.parts.d, 'day')} from now.</p>`;

  $('birthInfo').innerHTML =
    row('Born on', `${dayName}, ${dobStr}`) +
    row('Date of Birth', dobStr) +
    row('Day of Birth', dob.getDate()) +
    row('Month of Birth', MONTHS[dob.getMonth()]) +
    row('Year of Birth', dob.getFullYear()) +
    row('Day of the Week', dayName);

  $('zodiac').innerHTML = `<span class="z-sym" aria-hidden="true">${z.symbol}</span><div><div class="z-name">${z.name}</div><div class="muted">${z.range}</div></div>`;

  $('lifeStats').innerHTML =
    row('Heartbeats (≈72/min)', '≈ ' + num(m.secs / 60 * 72)) +
    row('Breaths (≈16/min)', '≈ ' + num(m.secs / 60 * 16)) +
    row('Sleep hours (≈8h/day)', '≈ ' + num(m.days * 8)) +
    row('Days lived', '≈ ' + num(m.days)) +
    row('Weeks lived', '≈ ' + num(wk));

  renderMilestones();

  const nbLine = nb.today ? 'Today! 🎉' : longDate(nb.date);
  const daysLine = nb.today ? '0 Days (Happy Birthday!)' : plural(nb.days, 'Day');
  state.summary = `${name ? name + '\n' : ''}My Age:\n${ageStr}\n\nDate of Birth:\n${dobStr}\n\nNext Birthday:\n${nbLine}\n\nDays Until Birthday:\n${daysLine}\n\nZodiac:\n${z.name}`;

  $('printSheet').innerHTML = `<h1>Age Calculator Result</h1>
    ${name ? `<p><b>Name:</b> ${escapeHTML(name)}</p>` : ''}
    <p><b>Date of Birth:</b> ${dobStr}</p>
    <p><b>Calculation Date:</b> ${longDate(asOf)}</p>
    <p><b>Exact Age:</b> ${ageStr}</p>
    <p><b>Next Birthday:</b> ${nb.today ? 'Today' : longDate(nb.date) + ' (' + WEEKDAYS[nb.date.getDay()] + ')'}</p>
    <p><b>Zodiac:</b> ${z.symbol} ${z.name}</p>
    <p><b>Total Days:</b> ${num(m.days)}</p>`;
}

function escapeHTML(s) { return s.replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch])); }

/* ---------- Milestones ---------- */
function milestoneData() {
  const { dob, asOf } = state;
  return MILESTONES.map(n => {
    const date = new Date(dob.getFullYear(), dob.getMonth(), dob.getDate() + n);
    const diff = dayDiff(asOf, date);
    return { n, date, diff, status: diff < 0 ? 'done' : diff === 0 ? 'today' : 'upcoming' };
  });
}
function nextMilestoneFact() {
  const nx = milestoneData().find(x => x.diff >= 0);
  if (!nx) return 'You have passed all the major day milestones listed here.';
  return nx.diff === 0 ? `You reach ${num(nx.n)} days old today!` : `You will reach ${num(nx.n)} days old on ${longDate(nx.date)}.`;
}
function renderMilestones() {
  const list = milestoneData();
  const nx = list.find(x => x.diff >= 0);
  $('nextMs').textContent = nx
    ? `Next Milestone: ${num(nx.n)} Days Old — ${nx.diff === 0 ? 'today!' : longDate(nx.date) + ' (' + WEEKDAYS[nx.date.getDay()] + ', in ' + plural(nx.diff, 'day') + ')'}`
    : 'You have passed every milestone listed below.';
  $('msList').innerHTML = list.map(x => `<li class="${x.status === 'done' ? 'done' : ''} ${nx && x.n === nx.n ? 'next' : ''}">
    <b>${num(x.n)} Days Old</b>${longDate(x.date)}<br><em>${x.status === 'done' ? 'Reached ' + plural(-x.diff, 'day') + ' before the calculation date' : x.status === 'today' ? 'Today!' : 'In ' + plural(x.diff, 'day')}</em></li>`).join('');
}

/* ---------- Live counter ---------- */
function renderLive(m) {
  const c = m.c;
  $('live').innerHTML = [[c.y, 'Years'], [c.m, 'Months'], [c.d, 'Days'], [p2(m.h), 'Hours'], [p2(m.mi), 'Minutes'], [p2(m.s), 'Seconds']]
    .map(([v, l]) => card(v, l)).join('');
}
function tick() {
  if (!state.dob) return;
  if (dayDiff(state.asOf, todayStart()) !== 0) { calculate(); return; }   // midnight rollover
  const m = measure();
  renderLive(m);
  const set = (id, v) => { const el = $(id); if (el) el.textContent = num(v); };
  set('uH', m.secs / 3600); set('uM', m.secs / 60); set('uS', m.secs);
}
function startTimer() { stopTimer(); if (state.live) state.timer = setInterval(tick, 1000); }
function stopTimer() { if (state.timer) { clearInterval(state.timer); state.timer = null; } }

function countUp(el, target) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches || target < 2) { el.textContent = target; return; }
  const start = performance.now(), dur = 700;
  const step = now => {
    const p = Math.min((now - start) / dur, 1);
    el.textContent = Math.round(target * (1 - Math.pow(1 - p, 3)));
    if (p < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

/* ---------- Date difference ---------- */
function diffCalc() {
  const s = parseDate($('dStart').value), e = parseDate($('dEnd').value), out = $('dOut');
  out.hidden = true;
  if (!$('dStart').value || !s) return showError($('dErr'), 'Please enter a valid start date.');
  if (!$('dEnd').value || !e) return showError($('dErr'), 'Please enter a valid end date.');
  if (s > e) return showError($('dErr'), 'The start date cannot be later than the end date.');
  showError($('dErr'), '');
  const c = calDiff(s, e), days = dayDiff(s, e);
  out.innerHTML =
    card(plural(c.y, 'Year'), 'Years') + card(plural(c.m, 'Month'), 'Months') + card(plural(c.d, 'Day'), 'Days') +
    card(num(days), 'Total days') + card(num(days / 7), 'Total weeks') +
    card(num(days * 24), 'Total hours') + card(num(days * 1440), 'Total minutes');
  out.hidden = false;
}

/* ---------- Copy / Share / Print ---------- */
let toastTimer;
function toast(msg) {
  const t = $('toast'); t.textContent = msg;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.textContent = ''; }, 3000);
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; }
  catch (_) {
    try {
      const ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      const ok = document.execCommand('copy'); ta.remove(); return ok;
    } catch (__) { return false; }
  }
}
const needResult = () => { if (!state.dob) { toast('Calculate an age first.'); return true; } return false; };

async function onCopy() {
  if (needResult()) return;
  toast(await copyText(state.summary) ? 'Copied successfully!' : 'Could not copy. Please select and copy the result manually.');
}
async function onShare() {
  if (needResult()) return;
  if (navigator.share) {
    try { await navigator.share({ title: 'My Age', text: state.summary }); return; }
    catch (e) { if (e && e.name === 'AbortError') return; }
  }
  toast(await copyText(state.summary) ? 'Sharing is not available here, so the result was copied instead.' : 'Sharing is not available in this browser.');
}
function onPrint() { if (!needResult()) window.print(); }

/* ---------- Reset / Today ---------- */
function reset() {
  stopTimer();
  ['name', 'dob', 'asOf'].forEach(id => { $(id).value = ''; });
  showError($('err'), '');
  $('results').hidden = true;
  $('printSheet').innerHTML = '';
  Object.assign(state, { dob: null, asOf: null, live: false, name: '', summary: '' });
  $('toast').textContent = '';
  $('dob').focus();
}

/* ---------- Theme & menu ---------- */
function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  const dark = t === 'dark';
  $('themeBtn').textContent = dark ? '☀️ Light' : '🌙 Dark';
  $('themeBtn').setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
}
function initTheme() {
  let t = null;
  try { t = sessionStorage.getItem('theme'); } catch (_) {}
  if (!t) t = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  applyTheme(t);
  $('themeBtn').addEventListener('click', () => {
    const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    try { sessionStorage.setItem('theme', next); } catch (_) {}
  });
}

/* ---------- Init ---------- */
function init() {
  initTheme();
  const max = toISO(todayStart());
  ['dob', 'asOf', 'dStart'].forEach(id => $(id).setAttribute('max', max));
  $('year').textContent = new Date().getFullYear();

  $('calcBtn').addEventListener('click', calculate);
  $('resetBtn').addEventListener('click', reset);
  $('todayBtn').addEventListener('click', () => { $('asOf').value = toISO(todayStart()); });
  $('dBtn').addEventListener('click', diffCalc);
  $('copyBtn').addEventListener('click', onCopy);
  $('shareBtn').addEventListener('click', onShare);
  $('printBtn').addEventListener('click', onPrint);
  ['name', 'dob', 'asOf'].forEach(id => $(id).addEventListener('keydown', e => { if (e.key === 'Enter') calculate(); }));

  const menuBtn = $('menuBtn'), nav = $('nav');
  menuBtn.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuBtn.setAttribute('aria-expanded', open);
    menuBtn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  });
  nav.addEventListener('click', e => { if (e.target.tagName === 'A') { nav.classList.remove('open'); menuBtn.setAttribute('aria-expanded', 'false'); } });
}
init();
